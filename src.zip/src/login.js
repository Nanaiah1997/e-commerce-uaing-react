import React,{useState} from 'react';
import Header from './header';
import Footer from "./footer";
const Login = () =>{
    return(
        <>
            <Header/>
            <div className='container mt-5 height600'>
                <div className='row'>
                    <div className='col-lg-12'>
                        <h1 className='text-center'> Login </h1>
                    </div>
                </div>
                <div className='row mt-4'>
                    <div className='col-lg-4'></div>
                    <div className='col-lg-4'>
                        <div className='card'>
                            <div className='card-header bg-danger text-white'>
                                Enter Login Details
                            </div>
                            <div className='card-body'>
                                <div className='mb-3'>
                                    <label>e-Mail Id</label>
                                    <input type="text" className='form-control'/>
                                </div>
                                <div className='mb-3'>
                                    <label>Password</label>
                                    <input type="password" className='form-control'/>
                                </div>
                            </div>
                            <div className='card-footer text-center'>
                                <button className='btn btn-primary'>Login</button>
                            </div>
                        </div>
                    </div>
                    <div className='col-lg-4'></div>
                </div>
            </div>
            <Footer/>
        </>
    )
}
export default Login;